/**
 * Helper classes included (mostly copied) from the BouncyCastle 1.46 library. 
 * This was done to fix errors present in BouncyCastle, and this package is going to be 
 * removed when BC is fixed.
 * <p>
 * Warning: this package contains internal implementation of the library. It is not
 * guaranteed that API of the classes from this package will not change in future releases.
 */
package eu.emi.security.authn.x509.helpers.pkipath.bc;

