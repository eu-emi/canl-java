/**
 * Contains API of the library. The interfaces defined here are implemented
 * by the classes from the the <tt>eu.emi.security.authn.x509.impl</tt> package.
 */
package eu.emi.security.authn.x509;

